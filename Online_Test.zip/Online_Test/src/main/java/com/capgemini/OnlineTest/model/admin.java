package com.capgemini.OnlineTest.model;
import com.capgemini.OnlineTest.controller.*;
import com.capgemini.OnlineTest.dao.MainClass;

import java.io.IOException;
import java.io.Serializable;
import java.util.Scanner;
public class admin implements Serializable{
	
	public void login() throws ClassNotFoundException, IOException
	{	
		adminServices adminservices=new adminServices();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter admin name");
		String admin=sc.nextLine();
		System.out.println("Enter password");
		String pass=sc.nextLine();
		
		if(admin.equalsIgnoreCase("admin") && pass.equalsIgnoreCase("admin"))
		{
			System.out.println("ADMIN LOGIN SUCCESSFULL !");
			System.out.println("Select the task you want to do -:");
			System.out.println("1. ADD TEST");
			System.out.println("2. DELETE TEST");
			System.out.println("3. ADD QUESTION");
			System.out.println("4. DELETE QUESTION");
			System.out.println("5. Back to Login");

			int x=sc.nextInt();
			switch(x)
			{
			case 1:adminservices.addTest();
					break;
			case 2:adminservices.deleteTest();
					break;
			case 3:adminservices.addQuestion();
					break;
			case 4:adminservices.deleteQuestion();
					break;
			case 5:MainClass.main(null);
			default:
				System.out.println("Wrong input");
			}
		}
		else
		{
			System.out.println("Wrong Credentials , Try Again..");
		}
		
}
	

	
	

}
