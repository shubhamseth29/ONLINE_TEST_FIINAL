package com.capgemini.OnlineTest.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Scanner;

import com.capgemini.OnlineTest.model.Question;
import com.capgemini.OnlineTest.model.Test;



public class adminServices implements Serializable 
{
	Scanner sc=new Scanner(System.in);
	static LinkedHashMap<String,Test> allTests=new LinkedHashMap<String, Test>();
	String path="C:\\Users\\admin\\Documents\\workspace-sts-3.9.9.RELEASE\\Online_Test\\src\\main\\java\\com\\capgemini\\OnlineTest\\resources\\TestData.txt";
	
	

	public void addTest() throws ClassNotFoundException, IOException
	{	
		System.out.println("Enter Test Title");
		String title=sc.nextLine();
		Test test=new Test(title);
		allTests.put(title, test);
		
		File file = new File(path);
		FileInputStream f = new FileInputStream(file);
		ObjectInputStream s = new ObjectInputStream(f);
		LinkedHashMap<String,Test> user2 = (LinkedHashMap<String, Test>) s.readObject();
		allTests.putAll(user2);
		s.close();
		
		File file1 = new File(path);
		file1.createNewFile();
	    FileOutputStream f1 = new FileOutputStream(file1);
	    ObjectOutputStream s1 = new ObjectOutputStream(f1);
	    s1.writeObject(allTests);
	    s1.close();
	    
	    System.out.println("Test Added Successfully !");
		
		System.out.println("Do you want to add questions(Yes / No)");
		String ans=sc.nextLine();
		if(ans.equalsIgnoreCase("Yes"))
		{
			addQuestionFromTest(title);
		}
		else
			System.out.println("Okay Bye!");
	}
	
	public void deleteTest() throws ClassNotFoundException, IOException
	{
		System.out.println("Enter the test title you want to delete?");
		
			File file = new File(path);
			FileInputStream f = new FileInputStream(file);
			ObjectInputStream s = new ObjectInputStream(f);
			LinkedHashMap<String,Test> titles = (LinkedHashMap<String, Test>) s.readObject();
			s.close();
//		LinkedHashMap<String,Test> titles=deSerialize();
		System.out.println(titles.keySet());
		String title=sc.nextLine();
		if(titles.containsKey(title))
		{
			titles.remove(title);
		}
		else
			System.out.println("Kindly enter a title from above list !");
		allTests.putAll(titles);
		if(allTests.containsKey(title))
		allTests.remove(title);
		
		File file1 = new File(path);
		file1.createNewFile();
	    FileOutputStream f1 = new FileOutputStream(file1);
	    ObjectOutputStream s1 = new ObjectOutputStream(f1);
	    s1.writeObject(allTests);
	    s1.close();
//		serialize(allTests);
	    System.out.println("Test Deleted successfully !");
	}
	
	public void addQuestionFromTest(String title) throws IOException, ClassNotFoundException
	{	
		System.out.println("How many questions do you want to add?");
		int num=sc.nextInt();
		ArrayList<Question> list1=new ArrayList<Question>();
		while(num>0)
		{
			System.out.println("Enter question id (Number)");
			BigInteger id=sc.nextBigInteger();
			
			sc.nextLine();
			
			System.out.println("Enter question");
			String str=sc.nextLine();
			System.out.println("Enter options:");
			int count=1;
			HashMap<Integer, String> options=new HashMap<Integer, String>();
			while (count<5)
			{
				System.out.println("Set option "+ count);
				String opt= sc.nextLine();
				options.put(count,opt);
				count++;
			}
			int correctAnswer;
			System.out.println("Enter correct answer(1/2/3/4)");
			correctAnswer=sc.nextInt();
			Question question=new Question(id, options, str, correctAnswer);
			list1.add(question);
			num--;
		}
		allTests.get(title).setQuestionList(list1);
		System.out.println("Questions added succesfully");
		
		File file = new File(path);
		FileInputStream f = new FileInputStream(file);
		ObjectInputStream s = new ObjectInputStream(f);
		LinkedHashMap<String,Test> user2 = (LinkedHashMap<String, Test>) s.readObject();
		allTests.putAll(user2);
		s.close();
		
		File file1 = new File(path);
		file1.createNewFile();
	    FileOutputStream f1 = new FileOutputStream(file1);
	    ObjectOutputStream s1 = new ObjectOutputStream(f1);
	    s1.writeObject(allTests);
	    s1.close();
//		serialize(allTests);
		
	}
	public void addQuestion() throws IOException, ClassNotFoundException
	{	
		File file = new File(path);
		FileInputStream f = new FileInputStream(file);
		ObjectInputStream s = new ObjectInputStream(f);
		LinkedHashMap<String,Test> titles = new LinkedHashMap<String, Test>();
		titles = (LinkedHashMap<String, Test>) s.readObject();
		s.close();
//		LinkedHashMap<String,Test> titles=deSerialize();
		System.out.println("Enter Test Title in which you want to add !");
		System.out.println(titles.keySet());
		String title=sc.nextLine();
		ArrayList<Question> list1=new ArrayList<Question>();
		if(titles.containsKey(title))
		{
			System.out.println("How many questions do you want to add?");
			int num=sc.nextInt();
			while(num>0)
			{
				System.out.println("Enter question id (Number)");
				BigInteger id=sc.nextBigInteger();
				sc.nextLine();
				System.out.println("Enter question");
				String str=sc.nextLine();
				System.out.println("Enter options:");
				int count=1;
				HashMap<Integer, String> options=new HashMap<Integer, String>();
				while (count<5)
				{
					System.out.println("Set option "+ count);
					String opt= sc.nextLine();
					options.put(count,opt);
					count++;
				}
				int correctAnswer;
				System.out.println("Enter correct answer(1/2/3/4)");
				correctAnswer=sc.nextInt();
				Question question=new Question(id, options, str, correctAnswer);
				list1.add(question);
				num--;
		    }
			ArrayList<Question> finalList=new ArrayList<Question>();
			finalList=titles.get(title).getQuestionsList();
			finalList.addAll(list1);
			
			titles.get(title).setQuestionList(finalList);
			System.out.println("Questions added succesfully");
			
			File file3 = new File(path);
			FileInputStream f3= new FileInputStream(file3);
			ObjectInputStream s3 = new ObjectInputStream(f3);
			LinkedHashMap<String,Test> user2 = (LinkedHashMap<String, Test>) s3.readObject();
			allTests.putAll(user2);
			s3.close();
			
			File file1 = new File(path);
			file1.createNewFile();
		    FileOutputStream f1 = new FileOutputStream(file1);
		    ObjectOutputStream s1 = new ObjectOutputStream(f1);
		    s1.writeObject(titles);
			s1.close();
//			serialize(titles);
		}
		else
			System.out.println("Sorry Test with this Title not found.");
		
	}
	
	
	public void deleteQuestion() throws ClassNotFoundException, IOException
	{
		System.out.println("Enter the Test Title from which you want to delete questions?");
		File file = new File(path);
		FileInputStream f = new FileInputStream(file);
		ObjectInputStream s = new ObjectInputStream(f);
		LinkedHashMap<String,Test> titles = (LinkedHashMap<String, Test>) s.readObject();
		s.close();
//		LinkedHashMap<String,Test> titles=deSerialize();
		System.out.println(titles.keySet());
		String title=sc.nextLine();
		int flag=0;
		if(titles.containsKey(title))
		{
			System.out.println("The list of questions in test \""+ title+"\" are:  ");
			System.out.println(titles.get(title).getQuestionsList());
			System.out.println("Enter the Question Id you want to delete ! ");
			BigInteger id=sc.nextBigInteger();
			//sc.nextLine();

			ArrayList<Question> list;
			list = titles.get(title).getQuestionsList();
			//System.out.println(list);
			for(int j=0;j<list.size();j++)
			{
				Question q;
				q = list.get(j);
				System.out.println(q.getQuestionId());
				if(q.getQuestionId().equals(id))
				{
					list.remove(j);
					titles.get(title).setQuestionList(list);
					flag=1;
					System.out.println("Question Removed Successfully..!");
					break;
				}
			}

			if(flag==0)
			{
				System.out.println("Question not found !!");
			}
			File file1 = new File(path);
			FileInputStream f1= new FileInputStream(file1);
			ObjectInputStream s1 = new ObjectInputStream(f1);
			LinkedHashMap<String,Test> user2 = (LinkedHashMap<String, Test>) s1.readObject();
			allTests.putAll(user2);
			s1.close();
			
			File file2 = new File(path);
			file2.createNewFile();
		    FileOutputStream f2 = new FileOutputStream(file2);
		    ObjectOutputStream s2 = new ObjectOutputStream(f2);
		    s2.writeObject(titles);
		    s2.close();
//			serialize(titles);
			
		}
//		public void serialize(LinkedHashMap<String,Test> allTests) throws ClassNotFoundException, IOException
//		{
//			File file = new File(path);
//			FileInputStream f = new FileInputStream(file);
//			ObjectInputStream s = new ObjectInputStream(f);
//			LinkedHashMap<String,Test> user2 = (LinkedHashMap<String, Test>) s.readObject();
//			allTests.putAll(user2);
//			s.close();
//			
//			File file1 = new File(path);
//			file1.createNewFile();
//		    FileOutputStream f1 = new FileOutputStream(file1);
//		    ObjectOutputStream s1 = new ObjectOutputStream(f1);
//		    s1.writeObject(allTests);
//		    s1.close();
//		}
//		public LinkedHashMap<String,Test> deSerialize() throws ClassNotFoundException, IOException
//		{
//
//			File file = new File(path);
//			FileInputStream f = new FileInputStream(file);
//			ObjectInputStream s = new ObjectInputStream(f);
//			LinkedHashMap<String,Test> titles = (LinkedHashMap<String, Test>) s.readObject();
//			s.close();
//			return titles;
//		}
}
}
