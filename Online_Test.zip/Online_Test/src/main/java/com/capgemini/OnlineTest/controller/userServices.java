package com.capgemini.OnlineTest.controller;
import com.capgemini.OnlineTest.model.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class userServices  implements Serializable
{	
	public static void takeTest() throws IOException, ClassNotFoundException
	{		
		File file = new File("C:\\Users\\admin\\Documents\\workspace-sts-3.9.9.RELEASE\\Online_Test\\src\\main\\java\\com\\capgemini\\OnlineTest\\resources\\TestData.txt");
		FileInputStream f = new FileInputStream(file);
		ObjectInputStream s = new ObjectInputStream(f);
		LinkedHashMap<String,Test> user2 = (LinkedHashMap<String, Test>) s.readObject();
		s.close();
		ArrayList<Question> questionlist=new ArrayList<Question>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Select test title");
		//System.out.println(adminServices.allTests.keySet());
		System.out.println(user2.keySet());
		String title=sc.nextLine();
		//questionlist=adminServices.allTests.get(title).getQuestionsList();
		try 
		{
			questionlist=user2.get(title).getQuestionsList();
			int size=questionlist.size();
			int marks=0;
			for(Question q:questionlist)
			{	
				System.out.println(q.getQuestionId()+"->"+q.getQuestionTitle());
				System.out.println(q.getQuestionOptions());
				System.out.println("Enter answer(1/2/3/4)");
				int ans=sc.nextInt();
				if(ans==q.getQuestionAnswer())
					marks++;
			}
	
			System.out.println("Congratulations ! You scored "+marks+" out of "+size);
			System.out.println("Do you want to take another Test?(Y/N)");
			sc.nextLine();
			String ans=sc.nextLine();
			if(ans.equalsIgnoreCase("y"))
			{
				takeTest();
			}
			if(ans.equalsIgnoreCase("n"))
				System.out.println("Okay Bye ! Have a nice day !");
			else
				System.out.println("Invalid Input (Enter Y or N)");
		}
		catch(NullPointerException e)
		{
			System.out.println("Sorry , This test contains no questions as yet");
			System.out.println("Come Back Later :)");
			takeTest();
			
		}
		
		
	}

}
