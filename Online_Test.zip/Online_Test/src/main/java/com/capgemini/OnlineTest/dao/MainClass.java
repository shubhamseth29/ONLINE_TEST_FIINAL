package com.capgemini.OnlineTest.dao;
import com.capgemini.OnlineTest.model.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.InputMismatchException;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class MainClass  
{
	
	public static void main(String[] args) throws ClassNotFoundException, IOException  {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("--------WELCOME TO ONLINE TEST PORTAL--------");
		System.out.println("Login as : ");
		System.out.println("ADMIN (Press 1)");
		System.out.println("USER (Press 2)");
		System.out.println("EXIT (Press 3)");
		
		try
		{
			int x=sc.nextInt();
			if(x==1)
				new admin().login();
			
			else if(x==2) 
			{
				//new TestUser();
				TestUser.login();
			} 
			else if(x==3)
			{	
				System.out.println("BYE ! Have a nice day !");
				java.lang.System.exit(0);
			}
			else
				System.out.println("Wrong Input (Enter 1 or 2)");
				main(null);
				 
		}
		catch(InputMismatchException e)
		{
			System.out.println("Enter 1 or 2");
			main(null);
		}
		
	}
	
}
