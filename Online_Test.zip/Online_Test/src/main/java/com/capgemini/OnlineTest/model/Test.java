package com.capgemini.OnlineTest.model;
import java.io.Serializable;
import java.util.ArrayList;


@SuppressWarnings("serial")
public class Test implements Serializable {
	
	String testTitle;
	ArrayList<Question> questionList;
	
		
	@SuppressWarnings("unused")
	public Test(String testTitle)
	{
		this.testTitle=testTitle;
		ArrayList<Question> questionList=new ArrayList<Question>();
	}
	
	public ArrayList<Question> getQuestionsList()
	{
		return questionList;
	}
	
	public void setQuestionList(ArrayList<Question> questionList)
	{
		this.questionList=questionList;
	}

	//@Override
//	public String toString() {
//		return "Test [testTitle=" + testTitle + ", questionList=" + questionList + "]";
//	}
	
	

}
