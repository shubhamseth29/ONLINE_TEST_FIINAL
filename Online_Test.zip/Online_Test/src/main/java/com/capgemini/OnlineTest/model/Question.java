package com.capgemini.OnlineTest.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Question implements Serializable {
	
	BigInteger questionId;
	HashMap questionOptions;
	String questionTitle;
	Integer questionAnswer;
	
	
	
	public BigInteger getQuestionId() {
		return questionId;
	}

	public HashMap getQuestionOptions() {
		return questionOptions;
	}

	public String getQuestionTitle() {
		return questionTitle;
	}
	
	public Integer getQuestionAnswer() {
		return questionAnswer;
	}


	

	public Question(BigInteger questionId,HashMap questionOptions,String questionTitle,Integer questionAnswer )
	{
		this.questionId=questionId;
		this.questionOptions=questionOptions;
		this.questionTitle=questionTitle;
		this.questionAnswer=questionAnswer;
		
	}

	@Override
	public String toString()
	{
		return "Question Id= " + questionId + "\nQuestion Title= "+ questionTitle
				+ "\nQuestion Options= " + questionOptions + "\nQuestion Answer= "+ questionAnswer ;
	}
	

	
	
	

}
