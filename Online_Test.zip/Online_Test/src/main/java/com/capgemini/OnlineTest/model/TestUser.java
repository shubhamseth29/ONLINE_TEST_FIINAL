package com.capgemini.OnlineTest.model;
import com.capgemini.OnlineTest.controller.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class TestUser  implements Serializable
{
	int userId;
	String userName;
	String userPassword;
	public int getUserId() 
	{
		return userId;
	}
	public void setUserId(int userId) 
	{
		this.userId = userId;
	}
	public String getUserName() 
	{
		return userName;
	}
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	public String getUserPassword() 
	{
		return userPassword;
	}
	public void setUserPassword(String userPassword) 
	{
		this.userPassword = userPassword;
	}
	
	public static void login() throws IOException, ClassNotFoundException
	{	String path="C:\\Users\\admin\\Documents\\workspace-sts-3.9.9.RELEASE\\Online_Test\\src\\main\\java\\com\\capgemini\\OnlineTest\\resources\\UserInfo.txt";
		Scanner sc=new Scanner(System.in);
		TestUser testuser=new TestUser();
		System.out.println("New User(Press N) or ALready existing user(Press E) ?");
		
		String str=sc.nextLine();
		
		LinkedHashMap<String,String> user=new LinkedHashMap<String, String>();
		if(str.charAt(0)=='N')
		{
			System.out.println("Create username");
			String username=sc.nextLine();
			testuser.setUserName(username);
			System.out.println("Create Password");
			String password=sc.nextLine();
			testuser.setUserName(password);
			
			if(user.containsKey(username))
			{
				System.out.println("OOPS..! Username already exists !");
			}
			else
			{
				user.put(username, password);
				File file = new File(path);
				file.createNewFile();
			    FileOutputStream f = new FileOutputStream(file);
			    ObjectOutputStream s = new ObjectOutputStream(f);
			    s.writeObject(user);
			    s.close();
			        

			        
			    System.out.println("YAY!! SUCCESSFULLY REGISTERED...!! ");
			    new userServices().takeTest();
			}  
		}
		 
		else if(str.charAt(0)=='E')
		{
			 File file = new File(path);
			 FileInputStream f = new FileInputStream(file);
			 ObjectInputStream s = new ObjectInputStream(f);
			 LinkedHashMap<String, String> user2 = (LinkedHashMap<String, String>) s.readObject();
			 s.close();
			System.out.println("Enter your username");
			String username=sc.nextLine();
			
			if(user2.containsKey(username))
			{	System.out.println("Enter your password");
				String password=sc.nextLine();
				
				if(user2.get(username).equals(password))
				{
					System.out.println("YAYY..!! LOGIN SUCCESSFUL!");
					new userServices().takeTest();
				}
				else
				{
					System.out.println("Errr...!! Wrong PASSWORD !!");
				}
			}
			else
			{
				System.out.println("Ugh..!! Username does not exist ");
			}
			
		}
		else
			System.out.println("Wrong Input (Enter N or E)");
	}
	
	
}
